//
//  TEAttributesInspector.h
//  ThemeEngine
//
//  Created by Alexander Zielenski on 6/15/15.
//  Copyright © 2015 Alex Zielenski. All rights reserved.
//

#import "TEInspectorDetailController.h"

@interface TEAttributesInspector : TEInspectorDetailController

@end
