//
//  TEColorInspector.h
//  ThemeEngine
//
//  Created by Alexander Zielenski on 6/19/15.
//  Copyright © 2015 Alex Zielenski. All rights reserved.
//

#import "TEInspectorDetailController.h"

@interface TEColorInspector : TEInspectorDetailController

@end
