//
//  TKSVGRendition.h
//  ThemeKit
//
//  Created by Jeremy on 9/5/20.
//

#import <ThemeKit/TKRendition.h>

@interface TKSVGRendition : TKRendition
@property (nonatomic, strong) NSData *rawData;
@end

