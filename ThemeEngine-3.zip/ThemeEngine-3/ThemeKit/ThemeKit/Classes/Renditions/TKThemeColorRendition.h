//
//  TKThemeColorRendition.h
//  ThemeKit
//
//  Created by Jeremy on 1/17/22.
//  Copyright © 2022 Alex Zielenski. All rights reserved.
//

#import <ThemeKit/TKColorRendition.h>

@interface TKThemeColorRendition : TKColorRendition
@end
