//
//  CFTAsset+IKImageBrowserItem.h
//  carFileTool
//
//  Created by Alexander Zielenski on 8/16/14.
//  Copyright (c) 2014 Alexander Zielenski. All rights reserved.
//

#import "CFTAsset.h"

@interface CFTAsset (IKImageBrowserItem)

@end
