//
//  TEAnimationView.h
//  carFileTool
//
//  Created by Alexander Zielenski on 8/15/14.
//  Copyright (c) 2014 Alexander Zielenski. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TEAnimationView : NSView
@property (assign) CGFloat frameWidth;
@property (strong) NSBitmapImageRep *image;
@end
