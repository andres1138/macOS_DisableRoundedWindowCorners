//
//  CHAppDelegate.h
//  carFileTool
//
//  Created by Alexander Zielenski on 8/8/14.
//  Copyright (c) 2014 Alexander Zielenski. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TEAppDelegate : NSObject <NSApplicationDelegate>

@end
