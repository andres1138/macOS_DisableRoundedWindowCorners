//
//  CUIThemeGradient+Radial.h
//  carFileTool
//
//  Created by Alexander Zielenski on 8/14/14.
//  Copyright (c) 2014 Alexander Zielenski. All rights reserved.
//

#import "CUIThemeGradient.h"

@interface CUIThemeGradient (Radial)
- (void)drawInRect:(CGRect)arg1 relativeCenterPosition:(CGPoint)arg2 withContext:(CGContextRef)arg3;
@end
