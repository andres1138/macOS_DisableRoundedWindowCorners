//
//  TKIconRendition.h
//  ThemeKit
//
//  Created by Jeremy on 12/26/21.
//  Copyright © 2021 Alex Zielenski. All rights reserved.
//

#import <ThemeKit/ThemeKit.h>

@interface TKIconRendition : TKRendition
@end
