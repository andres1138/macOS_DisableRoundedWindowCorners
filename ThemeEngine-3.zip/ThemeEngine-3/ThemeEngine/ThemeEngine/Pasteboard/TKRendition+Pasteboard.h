//
//  TKRendition+Pasteboard.h
//  ThemeEngine
//
//  Created by Alexander Zielenski on 6/21/15.
//  Copyright © 2015 Alex Zielenski. All rights reserved.
//

#import <ThemeKit/ThemeKit.h>
#import "TERenditionPasteboardItem.h"

@interface TKRendition (Pasteboard) <TERenditionPasteboardItem>

@end
