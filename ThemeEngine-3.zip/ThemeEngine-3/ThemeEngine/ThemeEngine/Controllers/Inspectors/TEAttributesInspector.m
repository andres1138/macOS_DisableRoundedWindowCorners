//
//  TEAttributesInspector.m
//  ThemeEngine
//
//  Created by Alexander Zielenski on 6/15/15.
//  Copyright © 2015 Alex Zielenski. All rights reserved.
//

#import "TEAttributesInspector.h"

@interface TEAttributesInspector ()

@end

@implementation TEAttributesInspector

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
    self.inspectorView.canDrawSubviewsIntoLayer = NO;
}

@end
